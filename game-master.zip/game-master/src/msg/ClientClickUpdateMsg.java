package msg;

import entity.User;

public class ClientClickUpdateMsg extends BaseMsg{

	public ClientClickUpdateMsg(User user) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void doBiz() {
		// TODO Auto-generated method stub
		
	}

}
