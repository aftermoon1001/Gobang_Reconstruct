package msg;

public class ServerLoginFailMsg extends BaseMsg{

	public void doBiz() {
		
	}

}
